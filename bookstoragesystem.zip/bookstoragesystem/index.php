<?php
include 'connection.php';
include 'topnav.php';
?>

          <!-- Breadcrumbs-->
          

              <a> <h2> HOMEPAGE </h2> </a><br></br>
            </li>
           
          </ol>


              <div class="book_logo">
            <a href="#" class="image full"><img src="image/book.jpg" style="width:1050px;" style="background-attachment: fixed;" style="background-size: contain;"  > </a>

          <!-- Page Content -->
          <h4></h4>
          <hr> 
          <p> <h5>  </h5></p>
<?php include 'footer.php'; ?>