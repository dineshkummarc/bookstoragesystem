

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav" style="background-image: linear-gradient(,#2144);">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-home"></i>
            <span>HOMEPAGE</span>
          </a>
        </li>
         </li>
       <!-- <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw  fa-cloud"></i>
            <span>SERVICES</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item " href="urns.php">URNS</a> 
            <a class="dropdown-item " href="caskets.php">CASKETS</a>
            <a class="dropdown-item " href="vehicles.php">VEHICLES</a>
          </div> -->
        </li>
        <li class="nav-item">
          <a class="nav-link" href="author.php">
            <i class="fas fa-fw fa-users  "></i>
            <span>Author</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="publisher.php">
            <i class="fas fa-fw fa-users    "></i>
            <span>Publisher</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="books.php">
            <i class="fas fa-fw fa-book  "></i>
            <span>Books</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="genre.php">
            <i class="fas fa-fw fa-star   "></i>
            <span>Genre</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="shelflocation.php">
            <i class="fas fa-fw fa-search"></i>
            <span>Shelf Location</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">