<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="card-body">


<div class="card card-register mx-auto mt-5">
<div class="card-header">
                 

                        <form role="form" method="post" action="authortrans.php?action=add">
                            
                            <div class="form-group">
                            <input class="form-control" placeholder="Author Name" name="Name">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Address" name="Address">
                            </div> 
                            <button type="submit" class="btn btn-default"> <h6> Save Record </h6> </button>
                            <button type="reset" class="btn btn-default"> <h6> Clear Entry </h6> </button>
                            <!--<div class="form-group">
                              <input class="form-control" placeholder="Address" name="address">
                            </div> 
                             <div class="form-group">
                              <input class="form-control" placeholder="Phone No." name="phone_no">
                               </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Email Address" name="email_address">
                            </div>
                           
                            <button type="submit" class="btn btn-default"> <h6> Save Record </h6> </button>
                            <button type="reset" class="btn btn-default"> <h6> Clear Entry </h6> </button>


                      </form>  
                    </div>
                  ari di oh!-->
                </form>
                </div>
</div>
                </div>

        </div>

      </body>

        <!-- /.container-fluid -->
 <?php include 'footer.php'; ?> 